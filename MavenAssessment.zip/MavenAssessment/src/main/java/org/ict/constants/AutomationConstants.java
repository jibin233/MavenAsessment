package org.ict.constants;

public class AutomationConstants {
	 
			
			public static String expusername="practice.swtesting@gmail.com";
			public static String expPassword="123";
			public static  String ExpectedValue=":: ICT ACADEMY OF KERALA ::";
			

			
			
		    public static String expname="Rambo";
			public static String exppassword="rambo@123";
			public static String expemail="rambo@gmail.com";
			public static String expdesignation="ARM";
			public static String expreportingto="Demo";
			public static String expmemberof="Staff";
		    public static String expempid="123456";
			public static String exppassword2="rambo@123";
			public static String expnumber="9632175780";
			public static String exptype="Permanent";
			public static String expaddress="Kochi";	
			
		}


